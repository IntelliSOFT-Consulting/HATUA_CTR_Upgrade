#CakeResque

CakeResque is a CakePHP plugin for Resque, a library for creating background jobs that can be processed offline later.

> Resque (pronounced like "rescue") is a Redis-backed library for creating background jobs, placing those jobs on multiple queues, and processing them later.

Refer to [website](http://cakeresque.kamisama.me) for documentation

*Take a look at [Fresque](https://github.com/kamisama/Fresque) if you want a version for generic PHP application*